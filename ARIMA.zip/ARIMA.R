getwd()
setwd("C:/Users/admin/Desktop/labs")


df1 <- read.csv("hw6_USGDP.csv")
df1

df2 <- read.csv("hw6_one_family_homes.csv")
df2

install.packages("fpp2")
library(fpp2)



# 1



# a

set.seed(123456)
wn <- ts(rnorm(200))
wn

var(wn)

autoplot(wn)
acf(wn)
pacf(wn)

# We have one peak that differs from zero at the 5% level (k=19). However, this is to be
# expected due to the variation in sampling from the normal distribution.

# We use DWN as a model for the residuals / as a confirmation that we have eliminated any
# remaining serial correlation from the residuals and thus have a good model fit, so we
# really do not expect anything physically meaningful to be happening at k=19.



# b

ar1 <- ts(data.frame(matrix(rep(0),200,1)))
ar1[1,1] <- wn[1]
for (i in 2:200) {
  ar1[i,1] <- 0.6*ar1[i-1,1] + wn[i] 
}
autoplot(ar1)

acf(ar1)
pacf(ar1)

# Judging from the autoplot, there seems to be some sort of a pattern with the observations
# going up and down after certain intervals. ACF shows there is a statistical significance
# for lags 1 to 4 only, confirming there is some sort of a correlation. The Pacf plot shows
# a significant spike only at lag 1, meaning that all the higher-order autocorrelations are
# effectively explained by the lag-1 autocorrelation and indicating an AR (1) model.



# c

ar2.1 <- ts(data.frame(matrix(rep(0),200,1)))
ar2.1[1,1] <- wn[1]
ar2.1[2,1] <- wn[2]
for (i in 3:200) {
  ar2.1[i,1] <- 0.6*ar2.1[i-1,1] + 
    0.3*ar2.1[i-2,1] + wn[i] 
}
autoplot(ar2.1)

acf(ar2.1)
pacf(ar2.1)

# Once again, the autoplot shows a pattern: there are visible intervals on the graph. We need
# to explore ACF and PACF in order to find further evidence of correlation. Most of the
# spikes are statistically significant this time (lags 1 trough 14) indicating a much
# stronger correlation with prior periods. The Pacf plot shows significance at lags 1 and 2,
# indicating AR1 and AR2 models.



# d

ar2.2 <- ts(data.frame(matrix(rep(0),200,1)))
ar2.2[1,1] <- wn[1]
ar2.2[2,1] <- wn[2]
for (i in 3:200) {
  ar2.2[i,1] <- 0.8*ar2.2[i-1,1] + 
    - 0.3*ar2.2[i-2,1] + wn[i] 
}
autoplot(ar2.2)

acf(ar2.2)
pacf(ar2.2)

# This time the autoplot doesn't show a clear correlation. This is reinforced by ACF with
# only two first logs being significant now. The Pacf plot shows significance at lags
# 1 and 2, indicating AR1 and AR2 models. Lag two is now negative because of our
# second parameter.



# e

ma <- ts(data.frame(matrix(rep(0),200,1)))
ma[1,1] <- wn[1]
for (i in 2:200) {
  ma[i,1] <- wn[i] + 0.6*wn[i-1] 
}
autoplot(ma)

acf(ma)
pacf(ma)


# The autoplot doesn't really show visible correlation. For the PACF, we see two spikes
# at lag 1 and 2 followed by generally non-significant values. ACF is showing only log 1
# over the confidence level, indicating MA1 model.



# f

arma <- ts(data.frame(matrix(rep(0),200,1)))

arma[1,1] <- wn[1]
for (i in 2:200) {
  arma[i,1] <- wn[i] + 0.5*arma[i-1,1] + 
    0.4*wn[i-1] 
}
autoplot(arma)

acf(arma)
pacf(arma)


# We can see some sort of a pattern by looking at the autoplot. ACF values, however, die
# out after lag 3, so there's no significant correlation, which is to be expected from an
# ARMA(1,1) model. PACF shows spikes at 1 and 2. The ACF and PACF both decay slowly, which
# indicates an ARMA process. It seems reasonable that both polynomials should have 2 lags
# based on the lengths of the autocorrelations and partial autocorrelations.



# g

arima_G <- arma
arima_G[1,1] <- wn[1]
for (i in 2:200) {
  arima_G[i,1] <- arima_G[i-1,1] + arma[i]
}

autoplot(arima_G)
acf(arima_G)
pacf(arima_G)


# There is a very obvious pattern this time on the autoplot graph. All spikes are above our
# significance level on the ACF graph indicating a strong correlation, but perhaps the
# autocorrelations after lag 2 are merely due to the propagation of the autocorrelation at
# lag 1. This is confirmed by the PACF plot that has a significant spike only at lags 1 and
# 2 meaning that all the higher-order autocorrelations are effectively explained by the
# lag-1 and lag-2 autocorrelation.



# h

arima_H <- ts(arima_G, frequency = 4)
arima_H[1] <- wn[1]
arima_H[2] <- arima_G[2]
for (i in 5:200) {
  arima_H[i,] <- arima_H[i-2,] + arima_G[i-4,] + arima_G[i]
}
autoplot(arima_H)
acf(arima_H)
Pacf(arima_H) 

# There is a very visible pattern with the observations going up until point 20 and then
# starting to gradually go down. All spikes are above our significance level on the ACF
# graph indicating a strong correlation. PACF, however, has a significant spike only at
# lag 1 meaning that all the higher-order autocorrelations are effectively explained by the
# lag-1 autocorrelation.



# 2



# a

str(df1)  
gdp <- ts(df1$USGDP, frequency = 4)
(lambda <- BoxCox.lambda(gdp))

autoplot(BoxCox(gdp,lambda))

# The best lambda is 0.2351377.



# b

fit_arima <- auto.arima(gdp, seasonal = FALSE)
summary(fit_arima)

# The chosen model is ARIMA(2,2,5): AR(2) with 2 non-seasonal differences needed for
# stationarity, and 5 MA terms.

# RMSE = 33011. AIC = 6907.



# c

difference <- diff(gdp, 4)
sim1 <- arima(difference, order = c(2,0,2))
summary(sim1)

# RMSE = 18136. AIC = 6503.


sim2 <- arima(difference, order = c(3,0,0))
summary(sim2)

# RMSE = 18473. AIC = 6511.

sim3 <- arima(difference, order = c(2,0,0))
summary(sim3)

# RMSE = 18830. AIC = 6520.

# ARIMA (2,0,2) seems to perform better than the rest judging by the lowest RMSE and AIC.
# This may be due to the fact that the auto.arima() function does not simply find the model
# with the lowest AICc value. It also carries out several checks to ensure the model is
# numerically well-behaved.



# d

res <- residuals(sim1)
ggtsdisplay(res)

# There are bars above the the confidence level both for ACF and PACF, indicating there is
# still autocorrelation present.



# e

frcst <- forecast(sim1, h = 8)
autoplot(frcst) +
  xlab("Timeline") +
  ylab("US GDP")

frcst



# f

fit_ets <- ets(gdp)
summary(fit_ets)

# ETS: RMSE = 17998, AIC = 7045.
# Chosen model: RMSE = 18136, AIC = 6503.

# The chosen model has a lower AIC, while ETS has a lower RMSE. Since AIC corrects the RMSE
# for the number of predictors in the model, thus allowing to account for overfitting, I
# would go with the chosen one rather than ETS.



# 3



# a

str(df2) 

sales <- ts(df2$SFH_Sales, frequency = 12)
(lambda <- BoxCox.lambda(sales))

# The best lambda is 0.5930056

autoplot(BoxCox(sales,lambda))



# b

fit_arima2 <- auto.arima(sales, seasonal = FALSE)
summary(fit_arima2)

# RMSE = 44.74, AIC = 7177



# c

#Let's try some other models:

difference2 <- diff(sales, 12)
sales_fit <- arima(difference2, order = c(2,0,0))
summary(sales_fit)

# RMSE = 64.85, ATC = 7557

sales_fit1 <- arima(difference2, order = c(2,0,1))
summary(sales_fit1)

# RMSE = 64.55, AIC = 7553

sales_fit2 <- arima(difference2, order = c(3,0,0))
summary(sales_fit2)

# RMSE = 64.60. AIC = 7554.

# The autoarima model seems to be performing the best.



# d

res2 <- residuals(fit_arima2)
ggtsdisplay(res2, main ='Auto Arima Residual Diagnostics Results')

# There are bars above the the confidence level both for ACF and PACF, indicating there is
# still autocorrelation present.



# e

frcst2 <- forecast(fit_arima2, h = 24)
autoplot(frcst2) +
  xlab("Time") +
  ylab("US Single Family Home Sales")



# f

fit_ets2 <- ets(sales)
summary(fit_ets2)

# RMSE = 45.04. AIC = 9712.


# The autoarima model has a lower RMSE and AIC, hence it would be the preferred one.